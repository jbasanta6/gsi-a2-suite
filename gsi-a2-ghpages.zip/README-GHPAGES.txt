1) Crea un repo en GitHub
2) Sube el contenido de esta carpeta
3) Settings → Pages → Deploy from a branch → main/root
4) Abre la URL https://TUUSUARIO.github.io/NOMBREDELREPO